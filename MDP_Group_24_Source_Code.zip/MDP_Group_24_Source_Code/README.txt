SC2079 MDP - GROUP 24 - SOURCE CODE SUBMISSION

Algo: Task 1 path planner and Task 1/Task 2 recognition services.
STM32/Task1 and STM32/Task2: the two firmware application versions.
RPi/Task1 and RPi/Task2: task-specific controllers and communication.
Android: one application shared by both tasks.

Every source file retains its original extension followed by .txt.
Contents match the current repository source. SOURCE_MANIFEST.txt
contains SHA-256 checksums. Build files, configurations, resources,
libraries, model weights and compiled output are excluded, following
the source submission instructions. Existing notices are retained.
The original repository is required to build and run the project.
