package com.example.mdpgroup24.bluetooth

import android.bluetooth.BluetoothDevice
import android.content.Context

object BluetoothSession :
    BluetoothConnectionService.Listener {

    interface Listener {

        fun onConnectionStateChanged(
            state: BluetoothConnectionService.ConnectionState,
            device: BluetoothDevice?
        )

        fun onMessageReceived(
            message: String
        )
    }


    private lateinit var connectionService:
            BluetoothConnectionService


    private val listeners =
        mutableSetOf<Listener>()


    // ============================================================
    // INITIALISE
    // ============================================================

    fun initialize(
        context: Context
    ) {

        if (::connectionService.isInitialized) {
            return
        }


        connectionService =
            BluetoothConnectionService(
                context.applicationContext,
                this
            )


        connectionService.startListening()
    }

    fun ensureListening() {

        if (!::connectionService.isInitialized) {
            return
        }


        connectionService.startListening()
    }


    // ============================================================
    // LISTENERS
    // ============================================================

    fun addListener(
        listener: Listener
    ) {

        listeners.add(
            listener
        )
    }


    fun removeListener(
        listener: Listener
    ) {

        listeners.remove(
            listener
        )
    }


    // ============================================================
    // CONNECTION
    // ============================================================

    fun connect(
        device: BluetoothDevice
    ) {

        if (
            !::connectionService
                .isInitialized
        ) {
            return
        }


        connectionService.connect(
            device
        )
    }


    fun disconnect() {

        if (
            !::connectionService
                .isInitialized
        ) {
            return
        }


        connectionService.disconnect()
    }


    val isConnected: Boolean

        get() =

            ::connectionService
                .isInitialized &&
                    connectionService
                        .isConnected


    // ============================================================
    // SEND
    // ============================================================

    fun send(
        message: String
    ): Boolean {

        if (
            !::connectionService
                .isInitialized
        ) {
            return false
        }


        return connectionService.write(
            message
        )
    }


    // ============================================================
    // CALLBACKS
    // ============================================================

    override fun onConnectionStateChanged(
        state: BluetoothConnectionService.ConnectionState,
        device: BluetoothDevice?
    ) {

        listeners
            .toList()
            .forEach { listener ->

                listener
                    .onConnectionStateChanged(
                        state,
                        device
                    )
            }
    }


    override fun onMessageReceived(
        message: String
    ) {

        listeners
            .toList()
            .forEach { listener ->

                listener
                    .onMessageReceived(
                        message
                    )
            }
    }
}