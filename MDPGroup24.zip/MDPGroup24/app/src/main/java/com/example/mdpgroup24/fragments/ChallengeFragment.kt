package com.example.mdpgroup24.fragments

import androidx.fragment.app.Fragment
import com.example.mdpgroup24.R

class ChallengeFragment : Fragment(R.layout.fragment_challenge)